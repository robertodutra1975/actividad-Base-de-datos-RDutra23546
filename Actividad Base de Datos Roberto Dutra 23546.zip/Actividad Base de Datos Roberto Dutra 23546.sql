/*
-- Query: SELECT * FROM actividad.alumno
LIMIT 0, 1000

-- Date: 2023-11-05 12:18
*/
INSERT INTO `` (`id`,`nombre`,`apellido`,`edad`,`fecha`,`provincia`) VALUES (1,'Ricardo','Dimínguez',58,'2023-11-04 22:12:45','Jujuy');
INSERT INTO `` (`id`,`nombre`,`apellido`,`edad`,`fecha`,`provincia`) VALUES (2,'Susana','González',65,'2023-11-04 22:14:21','Entre Ríos');
INSERT INTO `` (`id`,`nombre`,`apellido`,`edad`,`fecha`,`provincia`) VALUES (3,'Juan','Perez',33,'2023-11-04 22:23:15','Buenos Aires');
INSERT INTO `` (`id`,`nombre`,`apellido`,`edad`,`fecha`,`provincia`) VALUES (4,'Sebastián','Márquez',35,'2023-11-04 22:23:15','Buenos Aires');
INSERT INTO `` (`id`,`nombre`,`apellido`,`edad`,`fecha`,`provincia`) VALUES (5,'María','Díaz',55,'2023-11-04 22:23:15','Santa Cruz');
